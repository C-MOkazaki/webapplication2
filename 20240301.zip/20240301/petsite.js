
  let _title = document.getElementById("title");
  let _top = document.getElementById("top");
  let _pet = document.getElementById("pet");
  
  let visible = _top;
  let hiddn = _pet;
  let pagetitle = "TOP";

function setPage(num){
  
 if (num == 0) {
   visible = _top;
   hiddn = _pet;
 } else if (num == 2){
   visible = _pet;
   hiddn = _top;
   pagetitle = "ペット";
 }
 
  hiddn.classList.add("d-none");
  visible.classList.remove("d-none");
   _title.innerHTML = pagetitle;
}


